# 종가 스크리닝 → NXT 매수 → 익일 장초 매도 전략 프로그램

정규장 15:30 종가 데이터(등락률·거래량·이동평균)와 당일 공시(DART)·뉴스(네이버 금융)를
결합해 종목을 스크리닝하고, 요청하신 아래 타임라인에 맞춰 매매 "신호"를 자동 생성합니다.

1. **15:30** — 정규장 종가 확정 후 전 종목 스크리닝 실행 → 후보 종목 저장
2. **18:00~19:00** — 저장된 후보로 NXT 매수 신호 생성
3. **익일 08:00~09:00** — 전일 매수 후보에 대해 장초 매도 신호 생성 (야간 악재 공시 재확인 포함)

각 단계가 끝나면 **텔레그램으로 알림**이 오고, **휴대폰 홈 화면에 추가한 웹앱(PWA)**에서 언제든
최신 결과를 확인할 수 있습니다. 자세한 설정 방법은 아래 "📱 휴대폰에서 매일 확인하기" 참고.

## ⚠️ 먼저 알아야 할 제약사항 (정직하게 안내드립니다)

- **실제 매매 자동 실행은 하지 않습니다.** NXT 실시간 호가·주문 체결은 증권사 계좌 연동
  (예: 한국투자증권 KIS Developers, 키움 OpenAPI+)이 필요한데, 이는 계좌 정보/공인 인증이
  필요한 영역이라 이번 프로그램 범위에서 제외했습니다(설문에서 "매매 신호까지 자동 생성"을
  선택하신 것과 일치합니다). 이 프로그램은 **"무엇을 살지/팔지" 리스트를 자동으로 만들어주는
  도구**이고, 실제 주문은 사용자가 HTS/MTS에서 NXT 호가를 보고 직접 실행해야 합니다.
- **이 샌드박스 환경에서는 실거래 데이터로 테스트하지 못했습니다.** 이 작업환경의 네트워크
  정책이 `data.krx.co.kr`, `finance.naver.com`, `opendart.fss.or.kr` 로의 접속을 모두 차단하고
  있어(`curl` 로도 confirm: CONNECT tunnel 403), pykrx/DART/네이버 실제 호출을 여기서 실행할 수
  없었습니다. 대신 **실제 API가 반환하는 데이터 형식을 그대로 흉내 낸 목데이터로 모든 계산
  로직(이동평균, 거래량배수, 종가강도, 필터링, 점수화, 저장/로딩 흐름)을 단위 테스트로
  검증**했고 전부 통과했습니다(`test_pipeline.py` 요약 참고). 일반 인터넷이 되는 본인 PC나
  서버에서 실행하면 정상적으로 실제 데이터를 가져옵니다. **처음 실행 시 꼭 `python main.py
  screen` 결과를 직접 눈으로 확인해서 숫자가 말이 되는지 검증해보세요.**
- DART API 키가 없으면 공시 점수는 0점으로 처리되고 기술적 지표(등락률/거래량/이동평균/
  종가강도)만으로 스크리닝됩니다. 키는 https://opendart.fss.or.kr 에서 무료로 즉시 발급됩니다.
- 관리종목/거래정지 종목을 제외하는 로직은 pykrx 무료 API의 한계로 완전히 구현하지 못했습니다
  (시가총액·거래대금 하한선으로 상당 부분 걸러지지만 100% 보장은 아닙니다). 실제 매매 전
  종목명을 한 번 더 확인하시길 권장합니다.
- 날짜 계산은 서버의 시스템 시각이 UTC여도(클라우드 서버/GitHub Actions 러너는 보통 UTC)
  틀리지 않도록 내부적으로 한국시간(KST, UTC+9)을 명시적으로 사용합니다
  (`data_fetcher.now_kst()`). 특히 08:30 KST 매도 신호 시점은 UTC로는 전날 23:30이라, 이 처리가
  없으면 파일 날짜가 하루 밀리는 버그가 생길 수 있어 신경 써서 처리했습니다.

## 설치

```bash
cd stock_screener
pip install -r requirements.txt
cp .env.example .env
# .env 파일을 열어 DART_API_KEY / TELEGRAM_BOT_TOKEN 등을 채워 넣으세요.
```

## 사용법

```bash
# 1) 정규장 종가 스크리닝 (보통 15:30 이후 실행)
python main.py screen

# 2) NXT 매수 신호 생성 (18:00~19:00 사이 실행)
python main.py buy

# 3) 익일 장초 매도 신호 생성 (08:00~09:00 사이 실행)
python main.py sell

# 매일 자동 실행 (스케줄러 상시 구동: 15:35 / 18:30 / 08:30, KST)
python main.py schedule
```

결과는 `data/candidates_YYYYMMDD.json`, `data/buy_signals_YYYYMMDD.json`,
`data/sell_signals_YYYYMMDD.json` 로 저장되고, 실행 시 콘솔에도 요약이 출력됩니다.
서버에 상시 배포하려면 `python main.py schedule` 을 `systemd`/`pm2`/`nohup` 등으로 백그라운드
실행해두면 됩니다 (컴퓨터가 18:00~19:00, 익일 08:00~09:00에 켜져 있어야 합니다).

## 📱 휴대폰에서 매일 확인하기

스토어에 올리는 앱 대신, **① 텔레그램 알림**과 **② 홈 화면에 추가하는 모바일 웹앱(PWA)**
두 가지를 만들어 두었습니다. 배포 방법은 두 가지가 있습니다.

- **방법 A. GitHub Actions (추천, 상시 서버 없음)** — GitHub이 하루 3번(15:35/18:30/08:30
  KST) 딱 몇 분만 컴퓨터를 빌려줘서 스크리닝을 실행하고 바로 꺼집니다. **서버를 띄워두지
  않아도** 되고, 완전 무료입니다. 계산 결과는 저장소에 자동 커밋되고, 그 파일을 정적 웹페이지
  (GitHub Pages)가 그대로 보여줍니다. 텔레그램 알림이 곧 "알람" 역할을 하고, 알림이 오면
  휴대폰 홈 화면 아이콘(PWA)을 눌러 최신 결과를 확인하는 방식입니다.
- **방법 B. 상시 서버(VM) 방식** — 앞서 안내드렸던 Oracle Cloud 같은 서버를 계속 켜두고
  `python main.py schedule` 을 돌리는 방식입니다. 서버 관리가 조금 더 필요하지만, SSH로 직접
  로그인해서 디버깅하기는 더 편합니다.

**둘 중 하나만 고르면 됩니다.** 대부분은 방법 A가 더 간단하고 비용도 안 듭니다.

---

### 방법 A. GitHub Actions + GitHub Pages (서버 없음, 추천)

#### A-0. 미리 알아둘 점 (정직하게 안내)

- GitHub Actions의 예약 실행(cron)은 시스템 부하에 따라 **몇 분 정도 늦게 시작될 수 있습니다**
  (정확히 초 단위로 맞는 cron은 아닙니다). 개인 참고용 신호 생성에는 문제없는 수준입니다.
- GitHub Actions 러너도 결국 클라우드 데이터센터 IP라서, KRX/네이버 등이 데이터센터 IP를
  차단/제한할 가능성은 Oracle Cloud 같은 VM 방식과 **동일하게 존재**합니다(이 프로그램만의
  문제가 아니라 클라우드에서 국내 사이트를 스크래핑하는 모든 방식이 갖는 공통 리스크입니다).
  처음 설정 후 `workflow_dispatch`(수동 실행)로 꼭 한 번 테스트해서 정상 동작하는지 확인하세요.
- **GitHub Pages로 공개되는 웹페이지는 기본적으로 "공개 URL"입니다.** 비밀번호를 걸 수 없어서,
  링크(`https://<아이디>.github.io/<저장소명>/`)를 아는 사람은 누구나 스크리닝 결과를 볼 수
  있습니다. 종목 추천 리스트가 민감정보는 아니지만, 신경 쓰이신다면 저장소를 Private으로
  만드세요(개인 계정도 무료로 Private 저장소 + Pages 사용 가능). 그래도 Pages URL 자체는
  로그인 없이 열리니, 완전한 비공개가 필요하면 방법 B(비밀번호 걸린 웹앱)를 사용하세요.
- 60일 이상 저장소에 아무 활동이 없으면 GitHub이 예약 실행을 자동으로 꺼버릴 수 있는데,
  이 워크플로우 자체가 매일 커밋을 만들기 때문에 정상적으로 돌고 있는 한 이 문제는 생기지
  않습니다.

#### A-1. GitHub 저장소 만들고 코드 올리기

1. https://github.com 가입 (이미 있다면 생략)
2. 새 저장소 생성 (Private 추천, 이름 예: `stock-screener`)
3. 압축 푼 `stock_screener` 폴더 내용을 그 저장소에 푸시
   ```bash
   cd stock_screener
   git init
   git add .
   git commit -m "init: 주식 스크리너"
   git branch -M main
   git remote add origin https://github.com/<내아이디>/stock-screener.git
   git push -u origin main
   ```

#### A-2. 시크릿(비밀 키) 등록

저장소 페이지 → **Settings → Secrets and variables → Actions → New repository secret** 에서
아래 3개를 등록합니다 (DART/텔레그램 발급 방법은 아래 A-3 참고, 없어도 일단 동작은 합니다).

| 이름 | 값 |
|---|---|
| `DART_API_KEY` | opendart.fss.or.kr 에서 발급한 키 (없으면 공시 점수만 생략) |
| `TELEGRAM_BOT_TOKEN` | 텔레그램 봇 토큰 |
| `TELEGRAM_CHAT_ID` | 내 텔레그램 채팅 ID |

#### A-3. 텔레그램 알림 설정 (5분)

1. 텔레그램 앱에서 **@BotFather** 검색 → `/newbot` → 봇 이름 정하면 **토큰**을 줍니다.
2. 방금 만든 내 봇과 대화방을 열고 아무 메시지("안녕" 등)나 보냅니다.
3. 브라우저로 `https://api.telegram.org/bot<위에서_받은_토큰>/getUpdates` 접속 →
   응답 JSON에서 `"chat":{"id": 123456789, ...}` 의 숫자를 확인합니다.
4. 두 값을 위 A-2의 시크릿으로 등록합니다.

#### A-4. GitHub Pages 켜기

저장소 **Settings → Pages** → Source를 **"Deploy from a branch"**, Branch를 **`main` / `docs`**
폴더로 선택 → Save. 잠시 후 `https://<내아이디>.github.io/<저장소명>/` 주소가 생깁니다.

#### A-5. 테스트 실행

저장소 **Actions** 탭 → 왼쪽에서 워크플로우 하나 선택(예: "1) 15:30 종가 스크리닝") →
오른쪽 **"Run workflow"** 버튼으로 지금 바로 한 번 실행해봅니다. 성공하면:
- 텔레그램으로 메시지가 오고
- 저장소에 `docs/data/latest_screen.json` 파일이 자동 커밋되고
- Pages 주소를 열면 결과가 보입니다

이후에는 `.github/workflows/screen.yml`(15:35), `buy.yml`(18:30), `sell.yml`(다음날 08:30)이
매일 자동으로 실행됩니다.

#### A-6. 휴대폰 홈 화면에 추가하기

1. 휴대폰 브라우저로 `https://<내아이디>.github.io/<저장소명>/` 접속
2. **iPhone(Safari)**: 하단 공유 버튼 → "홈 화면에 추가"
   **Android(Chrome)**: 우측 상단 메뉴(⋮) → "홈 화면에 추가" / "앱 설치"
3. 홈 화면 아이콘을 탭하면 앱처럼 전체화면으로 열립니다. 텔레그램 알림이 오면 그때 열어서
   확인하면 됩니다.

---

### 방법 B. 상시 서버(VM) 방식

#### B-0. 상시 실행할 서버 준비 (PC가 없어도 됨)

**추천: Oracle Cloud "Always Free" 티어** — 개인 소규모 스크립트 하나 돌리는 용도로는 사양이
넉넉하고(1~4 vCPU, 6~24GB RAM 옵션), **평생 무료**입니다(신용카드 등록은 필요하지만 요금이
청구되지 않는 free 리소스만 사용).

1. https://www.oracle.com/cloud/free/ 에서 가입 (본인 인증/카드 등록 필요, 결제는 안 됨)
2. Compute → Create Instance, 이미지: **Ubuntu 22.04** (Always Free 대상 shape인
   `VM.Standard.E2.1.Micro` 또는 Ampere A1 선택)
3. SSH 키 생성/다운로드 후 아래처럼 접속
   ```bash
   ssh -i 다운로드한_키.pem ubuntu@서버_공인IP
   ```
4. 보안 목록(Security List)에서 8000번 포트(웹앱용)를 본인 접속용으로만 열어두면 좋습니다
   (전체 공개도 되지만, 아래 `WEBAPP_PASSWORD` 설정은 꼭 하세요).

*(카드 등록 자체가 부담스럽다면 월 3~5천원대 국내/해외 VPS(Vultr, 가비아 등)도 동일하게
동작합니다. 라즈베리파이 같은 상시 구동 미니서버가 이미 있다면 그걸 써도 됩니다.)*

#### B-1. 서버에 프로그램 올리고 실행

```bash
# 로컬에서 압축 파일을 서버로 전송
scp -i 다운로드한_키.pem stock_screener.zip ubuntu@서버_공인IP:~/

# 서버에서
ssh -i 다운로드한_키.pem ubuntu@서버_공인IP
sudo apt update && sudo apt install -y python3-pip unzip
unzip stock_screener.zip && cd stock_screener
pip3 install -r requirements.txt
cp .env.example .env && nano .env   # DART_API_KEY / TELEGRAM_* / WEBAPP_PASSWORD 입력
```

#### B-2. 텔레그램 알림 설정 (5분)

1. 텔레그램 앱에서 **@BotFather** 검색 → `/newbot` → 봇 이름 정하면 **토큰**을 줍니다.
   이 값을 `.env` 의 `TELEGRAM_BOT_TOKEN` 에 붙여넣으세요.
2. 방금 만든 내 봇과 아무 대화나 한 번 나눕니다 ("안녕" 등 아무거나 전송).
3. 브라우저로 `https://api.telegram.org/bot<위에서_받은_토큰>/getUpdates` 접속 →
   응답 JSON에서 `"chat":{"id": 123456789, ...}` 의 숫자를 `.env` 의 `TELEGRAM_CHAT_ID` 에 입력.
4. 이제 `python3 main.py screen` 등을 실행하면 텔레그램으로 바로 메시지가 옵니다.
   (설정을 안 해도 프로그램은 정상 동작하고, 알림만 생략됩니다.)

#### B-3. 상시 자동 실행 등록 (systemd)

`deploy/` 폴더의 서비스 파일을 참고해 등록합니다 (경로의 `ubuntu`/`/home/ubuntu/...` 는
본인 서버의 사용자명/경로에 맞게 수정하세요).

```bash
sudo cp deploy/stock-screener.service /etc/systemd/system/
sudo cp deploy/stock-screener-web.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now stock-screener.service       # 15:35/18:30/08:30 자동 스크리닝
sudo systemctl enable --now stock-screener-web.service    # 휴대폰 대시보드 (8000번 포트)

# 로그 확인
journalctl -u stock-screener.service -f
```

#### B-4. 휴대폰 홈 화면에 앱처럼 추가하기 (PWA)

1. 휴대폰 브라우저(Safari/Chrome)로 `http://서버_공인IP:8000` 접속
   (`.env` 에 `WEBAPP_PASSWORD` 를 설정했다면 아이디/비밀번호 입력창이 뜹니다)
2. **iPhone(Safari)**: 하단 공유 버튼 → "홈 화면에 추가"
   **Android(Chrome)**: 우측 상단 메뉴(⋮) → "홈 화면에 추가" / "앱 설치"
3. 홈 화면에 아이콘이 생기고, 탭하면 주소창 없이 앱처럼 전체화면으로 열립니다. 안에서
   15:30 스크리닝 / 18~19시 매수신호 / 익일 08~09시 매도신호 3개 탭을 볼 수 있고,
   당겨서 새로고침 버튼(↻)으로 최신화됩니다.

> 참고: 도메인 없이 IP:포트로 접속하면 http 라서 일부 iOS 버전에서 "홈 화면에 추가"가
> 제한될 수 있습니다. 문제가 있으면 무료 도메인(DuckDNS 등) 연결 + Let's Encrypt로 https 를
> 붙이는 것을 권장드리며, 필요하시면 그 설정도 도와드릴 수 있습니다.

## 스크리닝 조건 (config.py 에서 조정)

**기술적 조건 (15:30 종가 기준)**
- 등락률 3%~29.5% (급등주 포착, 상한가 직전 과열 종목은 기본 제외)
- 당일 거래량이 최근 20일 평균 대비 2배 이상 (수급 유입 확인)
- 종가강도 [(종가-저가)/(고가-저가)] 0.65 이상 (당일 저점 대비 종가 근처 강세 마감 → 익일 갭 유지 가능성)
- 5일선 > 20일선 (단기 상승 추세)
- 최소 시가총액 500억 / 최소 당일 거래대금 30억 (유동성·작전주 리스크 필터)

**뉴스/공시 조건**
- DART 당일 공시 제목에서 호재(공급계약·수주·무상증자·자사주매입 등) / 악재(유상증자·횡령·
  관리종목 등) 키워드 매칭
- 네이버 금융 종목뉴스 제목에서 긍정/부정 키워드 매칭

**과거 패턴 매칭 조건 (신규)**
- 후보 종목의 **최근 3거래일 일봉(시가/종가) 패턴**을 "1일차 몸통수익률 → 2일차 갭 → 2일차
  몸통수익률 → 3일차 갭 → 3일차 몸통수익률" 5개 값으로 벡터화합니다.
- 같은 종목의 **최근 3년치 일봉 이력**을 전부 훑어서, 이 벡터와 유클리드 거리가
  `PATTERN_SIMILARITY_THRESHOLD`(기본 0.04) 이내인 과거 3일 패턴 사례를 모두 찾습니다.
- 각 사례마다 "패턴 마지막날 종가 → 다음날 시가"가 상승했는지를 확인해 **승률**을 계산합니다.
- 사례가 `MIN_PATTERN_MATCHES`(기본 3건) 이상이고 승률이 `PATTERN_WIN_RATE_THRESHOLD`
  (기본 60%) 이상이면 `패턴확인=True` 로 표시되고, 승률×신뢰도(사례 수 비례)로 계산한
  패턴점수가 최종 랭킹에 반영됩니다. 사례가 아예 없거나 상장 이력이 짧은 종목(60거래일 미만)은
  0점(중립) 처리되어 불이익 없이 다른 조건만으로 평가됩니다.
- 결과 JSON에는 `패턴매칭수` / `패턴승률` / `패턴확인` / `패턴사례`(근접 사례 상위 5개, 날짜와
  당시 다음날 등락률 포함)가 함께 저장되어 왜 추천됐는지 직접 검증할 수 있습니다.

기술점수(가중치 0.45) + 뉴스점수(가중치 0.25) + 패턴점수(가중치 0.30)를 정규화해 합산한 뒤
상위 10개 종목을 최종 후보로 선정합니다. 조건/가중치/후보 개수는 모두 `config.py` 상단에서
바로 수정할 수 있습니다.

> 참고: 패턴 매칭은 종목당 3년치 일봉 이력을 1회 조회하므로(종목당 API 호출 1회), 기존
> 기술적 필터를 통과한 상위 30개 종목(`screener.CANDIDATE_STAGE_POOL_SIZE`)에 대해서만
> 실행되어 전체 유니버스를 매번 조회하지는 않습니다.

## 파일 구성

| 파일 | 역할 |
|---|---|
| `config.py` | 스크리닝 조건, 가중치, API 키 설정 |
| `data_fetcher.py` | pykrx 기반 KRX 시세/거래량/시가총액 수집, 이동평균·거래량배수·종가강도 계산 |
| `news_fetcher.py` | DART 공시 API + 네이버 금융 뉴스 크롤링, 키워드 기반 점수화 |
| `pattern_matcher.py` | 최근 3일 일봉 패턴을 과거 3년 이력과 비교해 유사 사례/승률 계산 |
| `screener.py` | 기술적 필터링 → 뉴스/공시 점수 + 패턴 점수 결합 → 최종 랭킹 |
| `signal_generator.py` | 3단계(스크리닝/매수신호/매도신호) 결과 생성, JSON 저장(`data/` + `docs/data/`), 텔레그램 알림 발송 |
| `telegram_notifier.py` | 텔레그램 봇 API로 각 단계 결과를 사람이 읽기 좋은 메시지로 발송 |
| `scheduler.py` | (방법 B 전용) APScheduler로 15:35 / 18:30 / 08:30 자동 실행 |
| `main.py` | CLI 진입점 |
| `.github/workflows/*.yml` | (방법 A 전용) GitHub Actions 예약 실행 - 15:35/18:30/08:30 KST에 스크립트 실행 후 결과 자동 커밋 |
| `docs/index.html` 등 | (방법 A 전용) 서버 없는 정적 PWA - GitHub Pages가 그대로 서빙, `docs/data/latest_*.json` 을 읽음 |
| `webapp/app.py` | (방법 B 전용) 휴대폰용 모바일 대시보드(PWA) - Flask 서버, 비밀번호 보호 가능 |
| `webapp/templates/index.html` | (방법 B 전용) PWA 화면 (탭 3개: 스크리닝/매수신호/매도신호) |
| `deploy/*.service` | (방법 B 전용) systemd 서비스 파일 (스케줄러 + 웹앱 상시 실행용) |

## 다음에 고려해볼 만한 개선 방향

- 증권사 API(KIS Developers 등) 연동 시 실시간 NXT 호가를 매수 신호에 반영 가능
- 백테스트 모듈 추가 (과거 스크리닝 조건으로 실제 익일 수익률을 검증해 조건 튜닝)
- 도메인 + HTTPS(Let's Encrypt) 적용해 PWA 오프라인 캐싱/알림 등 고급 기능 활용
- 카카오톡 알림(카카오 i 오픈빌더/알림톡)도 필요하시면 추가 가능 (텔레그램보다 발급 절차가 다소 복잡)
