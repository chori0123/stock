# -*- coding: utf-8 -*-
"""
과거 캔들 패턴 매칭 모듈.

추천 후보 종목의 "최근 3거래일 일봉(시가/종가) 패턴"을 벡터로 만들고, 같은 종목의
최근 N년(기본 3년) 일봉 이력에서 동일/유사한 3일 패턴이 있었던 시점들을 모두 찾는다.
그 각각의 시점에서 "패턴 마지막 날 종가 -> 다음날 시가"가 상승했는지를 확인해,
과거에 같은 패턴이 나타났을 때 다음날 시가가 오르는 경향이 있었는지를 통계로 점수화한다.

패턴 벡터 정의 (거래일 3일: D-2, D-1, D 기준, 값은 모두 비율(소수)):
    r1 = (D-2 종가 - D-2 시가) / D-2 시가                 # 1일차 몸통 수익률(양봉/음봉 크기)
    g2 = (D-1 시가 - D-2 종가) / D-2 종가                  # 1->2일차 갭
    r2 = (D-1 종가 - D-1 시가) / D-1 시가                  # 2일차 몸통 수익률
    g3 = (D 시가   - D-1 종가) / D-1 종가                  # 2->3일차 갭
    r3 = (D 종가   - D 시가)   / D 시가                    # 3일차 몸통 수익률

두 3일 패턴 벡터 사이의 유클리드 거리가 config.PATTERN_SIMILARITY_THRESHOLD 이하이면
"같은 패턴"으로 간주한다.
"""

import logging
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

import config
import data_fetcher

logger = logging.getLogger(__name__)


def compute_pattern_vector(window: pd.DataFrame) -> np.ndarray:
    """3행짜리(시가, 종가 컬럼 포함) DataFrame -> 5차원 패턴 벡터."""
    o1, c1 = float(window.iloc[0]["시가"]), float(window.iloc[0]["종가"])
    o2, c2 = float(window.iloc[1]["시가"]), float(window.iloc[1]["종가"])
    o3, c3 = float(window.iloc[2]["시가"]), float(window.iloc[2]["종가"])

    r1 = (c1 - o1) / o1 if o1 else 0.0
    g2 = (o2 - c1) / c1 if c1 else 0.0
    r2 = (c2 - o2) / o2 if o2 else 0.0
    g3 = (o3 - c2) / c2 if c2 else 0.0
    r3 = (c3 - o3) / o3 if o3 else 0.0
    return np.array([r1, g2, r2, g3, r3], dtype=float)


def _scan_history(hist: pd.DataFrame, target_vec: np.ndarray, threshold: float,
                   window_days: int = None) -> list:
    """hist(전체 이력, 오늘 포함, 날짜 오름차순)에서 target_vec 과 유사한 과거 3일 패턴을 모두 찾는다.

    반환: [{"date": 패턴 마지막날짜, "distance": float, "next_day_up": bool,
            "next_day_change_pct": float}, ...]
    오늘(맨 마지막) 패턴 자기 자신은 다음날 데이터가 없으므로 탐색 범위에서 자동 제외된다.
    """
    window_days = window_days or config.PATTERN_WINDOW_DAYS
    n = len(hist)
    matches = []
    # s: 패턴 시작 인덱스. 패턴은 [s, s+window_days-1], 다음날은 s+window_days 이어야 하므로
    # s + window_days <= n - 1 (즉 다음날 행이 실제로 존재해야 함)
    last_start = n - window_days - 1
    for s in range(0, last_start + 1):
        window = hist.iloc[s:s + window_days]
        vec = compute_pattern_vector(window)
        dist = float(np.linalg.norm(vec - target_vec))
        if dist <= threshold:
            day_last_close = float(window.iloc[-1]["종가"])
            next_row = hist.iloc[s + window_days]
            next_open = float(next_row["시가"])
            up = next_open > day_last_close
            change_pct = (next_open / day_last_close - 1) * 100 if day_last_close else 0.0
            matches.append({
                "date": str(window.index[-1])[:10],
                "distance": round(dist, 5),
                "next_day_up": up,
                "next_day_change_pct": round(change_pct, 2),
            })
    return matches


def evaluate_pattern(ticker: str, end_date: str) -> dict:
    """종목 하나에 대해 '최근 3일 패턴이 최근 3년간 유사 사례가 있었는지 + 그때 다음날 시가가
    올랐는지'를 평가한다.

    반환 딕셔너리는 항상 아래 키를 포함한다 (데이터 부족 시 매칭수=0, 패턴확인=False):
        패턴매칭수, 패턴상승수, 패턴승률(또는 None), 패턴확인(bool), 패턴점수(0~1),
        패턴사례(상위 5개, 거리 가까운 순)
    """
    empty_result = {
        "패턴매칭수": 0, "패턴상승수": 0, "패턴승률": None,
        "패턴확인": False, "패턴점수": 0.0, "패턴사례": [],
    }

    end_dt = datetime.strptime(end_date, "%Y%m%d")
    start_dt = end_dt - timedelta(days=int(config.PATTERN_LOOKBACK_YEARS * 365.25) + 10)
    hist = data_fetcher.get_ticker_ohlcv_history(ticker, start_dt.strftime("%Y%m%d"), end_date)
    if hist.empty or len(hist) < max(config.PATTERN_MIN_HISTORY_DAYS, config.PATTERN_WINDOW_DAYS + 1):
        return empty_result

    hist = hist.sort_index()
    if len(hist) < config.PATTERN_WINDOW_DAYS:
        return empty_result

    target_window = hist.iloc[-config.PATTERN_WINDOW_DAYS:]
    target_vec = compute_pattern_vector(target_window)

    matches = _scan_history(hist, target_vec, config.PATTERN_SIMILARITY_THRESHOLD)
    total = len(matches)
    if total == 0:
        return empty_result

    up_count = sum(1 for m in matches if m["next_day_up"])
    win_rate = up_count / total
    confirmed = (total >= config.MIN_PATTERN_MATCHES) and (win_rate >= config.PATTERN_WIN_RATE_THRESHOLD)

    # 신뢰도(confidence): 매칭 사례가 MIN_PATTERN_MATCHES 보다 적으면 점수를 비례해서 낮춘다.
    confidence = min(total / max(config.MIN_PATTERN_MATCHES, 1), 1.0)
    pattern_score = win_rate * confidence

    top_examples = sorted(matches, key=lambda m: m["distance"])[:5]

    return {
        "패턴매칭수": total,
        "패턴상승수": up_count,
        "패턴승률": round(win_rate, 3),
        "패턴확인": confirmed,
        "패턴점수": round(pattern_score, 4),
        "패턴사례": top_examples,
    }


def build_pattern_scores(tickers: list, end_date: str) -> dict:
    """후보 티커 리스트에 대해 evaluate_pattern 을 일괄 실행한다. {티커: evaluate_pattern 결과}"""
    out = {}
    for t in tickers:
        try:
            out[t] = evaluate_pattern(t, end_date)
        except Exception as e:
            logger.warning("패턴 매칭 실패 (%s): %s", t, e)
            out[t] = {
                "패턴매칭수": 0, "패턴상승수": 0, "패턴승률": None,
                "패턴확인": False, "패턴점수": 0.0, "패턴사례": [],
            }
    return out
