# -*- coding: utf-8 -*-
"""
텔레그램 알림 모듈.

TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID 가 설정되어 있지 않으면 조용히 아무것도 하지 않는다
(휴대폰 알림 없이 로컬/PWA로만 확인하는 사용자도 있을 수 있으므로).

봇 생성/채팅방 ID 확인 방법은 README.md "휴대폰에서 확인하기" 섹션 참고.
"""

import logging

import requests

import config

logger = logging.getLogger(__name__)

TELEGRAM_API = "https://api.telegram.org/bot{token}/sendMessage"


def is_configured() -> bool:
    return bool(config.TELEGRAM_BOT_TOKEN and config.TELEGRAM_CHAT_ID)


def send_message(text: str) -> bool:
    """텔레그램으로 메시지를 보낸다. 설정이 없거나 실패해도 예외를 던지지 않는다
    (알림 실패가 스크리닝/신호 생성 자체를 막으면 안 되므로)."""
    if not is_configured():
        logger.info("TELEGRAM_BOT_TOKEN/CHAT_ID 미설정 - 텔레그램 알림 생략")
        return False
    url = TELEGRAM_API.format(token=config.TELEGRAM_BOT_TOKEN)
    try:
        resp = requests.post(
            url,
            data={
                "chat_id": config.TELEGRAM_CHAT_ID,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            },
            timeout=10,
        )
        resp.raise_for_status()
        return True
    except Exception as e:
        logger.error("텔레그램 메시지 전송 실패: %s", e)
        return False


def _fmt_num(v, unit=""):
    if v is None:
        return "-"
    try:
        return f"{v:,.0f}{unit}"
    except (TypeError, ValueError):
        return str(v)


def format_screen_message(payload: dict) -> str:
    date = payload.get("date", "")
    items = payload.get("candidates", [])
    if not items:
        return f"📊 <b>[{date}] 종가 스크리닝</b>\n조건을 만족하는 종목이 없습니다."
    lines = [f"📊 <b>[{date}] 종가 스크리닝 결과 ({len(items)}개)</b>"]
    for i, c in enumerate(items, 1):
        pattern_tag = " 🔁패턴확인" if c.get("패턴확인") else ""
        lines.append(
            f"{i}. <b>{c.get('종목명')}</b>({c.get('티커')}) "
            f"{_fmt_num(c.get('종가'))}원 (+{c.get('등락률', 0):.1f}%) "
            f"거래량x{c.get('거래량배수', 0):.1f}{pattern_tag}"
        )
    return "\n".join(lines)


def format_buy_message(payload: dict) -> str:
    date = payload.get("date", "")
    items = payload.get("buy_candidates", [])
    if not items:
        return f"🌙 <b>[{date}] NXT 매수 신호</b>\n후보 종목이 없습니다."
    lines = [f"🌙 <b>[{date}] NXT 매수 신호 ({len(items)}개, 18:00~19:00 확인)</b>"]
    for i, c in enumerate(items, 1):
        pattern = ""
        if c.get("패턴확인") is not None:
            wr = c.get("패턴승률")
            wr_txt = f"{wr*100:.0f}%" if isinstance(wr, (int, float)) else "-"
            pattern = f" | 패턴승률 {wr_txt}" + (" ✅" if c.get("패턴확인") else "")
        lines.append(
            f"{i}. <b>{c.get('종목명')}</b>({c.get('티커')}) 참고가 {_fmt_num(c.get('참고매수가'))}원{pattern}"
        )
    lines.append("\n※ NXT 실제 호가는 HTS/MTS에서 꼭 확인 후 주문하세요.")
    return "\n".join(lines)


def format_sell_message(payload: dict) -> str:
    sell_date = payload.get("sell_date", "")
    items = payload.get("sell_candidates", [])
    if not items:
        return f"🌅 <b>[{sell_date}] 장초 매도 신호</b>\n대상 종목이 없습니다."
    lines = [f"🌅 <b>[{sell_date}] 장초 매도 신호 ({len(items)}개, 08:00~09:00 확인)</b>"]
    for i, c in enumerate(items, 1):
        flag = " 🚨우선매도" if c.get("우선매도권고") else ""
        lines.append(f"{i}. <b>{c.get('종목명')}</b>({c.get('티커')}){flag}")
    return "\n".join(lines)
