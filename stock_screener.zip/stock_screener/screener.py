# -*- coding: utf-8 -*-
"""
스크리닝 엔진.

1단계 (기술적 필터+스코어링): 정규장 15:30 종가 데이터 기준으로
   등락률 / 거래량 급증 / 종가강도 / 이동평균 정배열 / 유동성(거래대금) /
   시가총액 조건을 만족하는 종목을 골라 기술점수를 매긴다.
2단계 (뉴스/공시 스코어링): 1단계 통과 종목(상위 N개, 조회 비용 절약 목적)에 대해서만
   DART 공시 + 네이버 뉴스 점수를 조회한다.
2-1단계 (과거 패턴 매칭 스코어링): 같은 후보군에 대해, 최근 3거래일 시가/종가 패턴과
   동일 종목의 최근 3년 이력 중 유사 패턴이 있었는지 찾고, 그 다음날 시가가 상승했던
   비율(승률)을 점수화한다.
3단계: 세 점수를 가중합해 최종 랭킹을 만들고 상위 TOP_N_CANDIDATES 를 반환한다.
"""

import logging

import pandas as pd

import config
import data_fetcher
import news_fetcher
import pattern_matcher

logger = logging.getLogger(__name__)

CANDIDATE_STAGE_POOL_SIZE = 30  # 뉴스/패턴 조회는 비용이 크므로 기술점수 상위 N개까지만 조회


def _normalize(series: pd.Series) -> pd.Series:
    if series.empty:
        return series
    lo, hi = series.min(), series.max()
    if hi == lo:
        return series.apply(lambda x: 0.5)
    return (series - lo) / (hi - lo)


def apply_technical_filters(snap: pd.DataFrame) -> pd.DataFrame:
    df = snap.copy()
    before = len(df)

    df = df[(df["종가"] >= config.MIN_PRICE) & (df["종가"] <= config.MAX_PRICE)]
    df = df[df["거래대금"] >= config.MIN_TRADING_VALUE]
    if "시가총액" in df.columns:
        df = df[df["시가총액"] >= config.MIN_MARKET_CAP]

    df = df[(df["등락률"] >= config.MIN_CHANGE_PCT) & (df["등락률"] <= config.MAX_CHANGE_PCT)]
    df = df[df["거래량배수"] >= config.MIN_VOLUME_RATIO]
    df = df[df["종가강도"] >= config.MIN_CLOSE_STRENGTH]

    if config.REQUIRE_MA_ALIGNMENT:
        df = df[df["MA정배열"] == True]  # noqa: E712

    logger.info("기술적 필터: %d개 -> %d개", before, len(df))
    return df


def compute_technical_score(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["n_등락률"] = _normalize(df["등락률"])
    df["n_거래량배수"] = _normalize(df["거래량배수"].clip(upper=df["거래량배수"].quantile(0.95)))
    df["n_종가강도"] = _normalize(df["종가강도"])
    # 시가총액 대비 거래대금 비율(회전율 근사치)도 소폭 반영
    df["기술점수"] = (
        df["n_등락률"] * 0.4 + df["n_거래량배수"] * 0.35 + df["n_종가강도"] * 0.25
    )
    return df


def run_screen(end_date: str = None) -> pd.DataFrame:
    """15:30 종가 스크리닝을 실행해 최종 후보 리스트(DataFrame)를 반환한다."""
    snap = data_fetcher.build_snapshot_with_indicators(end_date)
    if snap.empty:
        logger.warning("스냅샷 데이터가 비어있습니다.")
        return snap

    filtered = apply_technical_filters(snap)
    if filtered.empty:
        logger.warning("기술적 조건을 만족하는 종목이 없습니다.")
        return filtered

    scored = compute_technical_score(filtered)
    scored = scored.sort_values("기술점수", ascending=False)

    pool = scored.head(CANDIDATE_STAGE_POOL_SIZE).copy()
    date = pool["날짜"].iloc[0]
    tickers = pool["티커"].tolist()

    news_scores = news_fetcher.build_news_scores(tickers, date)
    pool["뉴스점수"] = pool["티커"].map(lambda t: news_scores.get(t, {}).get("news_score", 0.0))
    pool["공시히트"] = pool["티커"].map(lambda t: news_scores.get(t, {}).get("disclosure_hits", []))
    pool["뉴스히트"] = pool["티커"].map(lambda t: news_scores.get(t, {}).get("news_hits", []))

    pattern_scores = pattern_matcher.build_pattern_scores(tickers, date)
    pool["패턴점수"] = pool["티커"].map(lambda t: pattern_scores.get(t, {}).get("패턴점수", 0.0))
    pool["패턴매칭수"] = pool["티커"].map(lambda t: pattern_scores.get(t, {}).get("패턴매칭수", 0))
    pool["패턴승률"] = pool["티커"].map(lambda t: pattern_scores.get(t, {}).get("패턴승률"))
    pool["패턴확인"] = pool["티커"].map(lambda t: pattern_scores.get(t, {}).get("패턴확인", False))
    pool["패턴사례"] = pool["티커"].map(lambda t: pattern_scores.get(t, {}).get("패턴사례", []))

    pool["n_기술점수"] = _normalize(pool["기술점수"])
    pool["n_뉴스점수"] = _normalize(pool["뉴스점수"])
    pool["n_패턴점수"] = _normalize(pool["패턴점수"])
    pool["최종점수"] = (
        pool["n_기술점수"] * config.WEIGHT_TECHNICAL
        + pool["n_뉴스점수"] * config.WEIGHT_NEWS
        + pool["n_패턴점수"] * config.WEIGHT_PATTERN
    )

    result = pool.sort_values("최종점수", ascending=False).head(config.TOP_N_CANDIDATES)

    cols = [
        "티커", "종목명", "시장", "날짜", "종가", "등락률", "거래량배수", "종가강도",
        "MA정배열", "거래대금", "시가총액", "기술점수", "뉴스점수",
        "패턴점수", "패턴매칭수", "패턴승률", "패턴확인", "패턴사례",
        "최종점수", "공시히트", "뉴스히트",
    ]
    cols = [c for c in cols if c in result.columns]
    return result[cols].reset_index(drop=True)
